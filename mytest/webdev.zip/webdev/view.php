<!DOCTYPE html>
<html>
<head>
    <title>View</title>
    <link href="css/style.css" rel="stylesheet" />
</head>
<body>

<h1> READ </h1>

<?php
    
    include 'connection.php';

    $sql = "SELECT id, firstname, lastname FROM user";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
    // output data of each row

?>

    <table id="customers">
    <tr>
        <th>ID</th>
        <th>First Name</th>
        <th>Last Name</th>
    </tr>

<?php
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td> " . $row["id"]. " </td>";
        echo "<td> " . $row["firstname"]. " </td>";
        echo "<td> " . $row["lastname"]. " </td>";
        echo "</tr>";
    }
    } else {
    echo "0 results";
    }

    echo "</table>";

    $conn->close();

?>


</body>
</html>



