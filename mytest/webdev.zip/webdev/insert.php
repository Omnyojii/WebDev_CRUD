<?php

include 'connection.php';

$fn = $_POST['firstname'];
$ln = $_POST['lastname'];

$sql = "INSERT INTO user (firstname, lastname)
        VALUES ('$fn', '$ln')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>

<p><a href="index.php"> Home </a></p>