<!DOCTYPE html>
<html>
<head>
    <title>Demo</title>
</head>
<body>

<h1> CRUD - Create - Read - Update - Delete </h1>

    <form action="insert.php" method="POST">
        <input type="text" name="firstname" placeholder="First Name"/>
        <input type="text" name="lastname" placeholder="Last Name"/>
        <input type="submit" name="submit"/>
    </form>

    <p><a href="view.php"> View </a></p>

</body>
</html>



