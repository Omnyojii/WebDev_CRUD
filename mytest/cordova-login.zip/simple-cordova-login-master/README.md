# simple-cordova-login
A Simple Cordova (PhoneGap) login using PHP &amp; MySQL
